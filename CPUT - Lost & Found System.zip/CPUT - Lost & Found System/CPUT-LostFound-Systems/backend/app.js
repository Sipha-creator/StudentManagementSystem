const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = 3000;

// Create the uploads directory if it doesn't exist
const uploadDir = path.join(__dirname, 'public', 'uploads');
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
}

// Configure storage for uploaded images
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'public/uploads/');
    },
    filename: (req, file, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, file.fieldname + '-' + uniqueSuffix + '.' + file.originalname.split('.').pop());
    }
});

const upload = multer({ storage: storage });

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Database connection config
const dbConfig = {
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'lost_found',
    port: 3307
};

// Function to get a database connection
async function getDbConnection() {
    return await mysql.createConnection(dbConfig);
}

// Base route
app.get('/', (req, res) => {
    res.send('🔍 Lost & Found API running...');
});

// Login endpoint
app.post('/login', async (req, res) => {
    const { usernameOrEmail, password } = req.body;

    if (!usernameOrEmail || !password) {
        return res.status(400).send('Username/email and password are required.');
    }

    let connection;
    try {
        connection = await getDbConnection();
        const sql = `SELECT UserID, PasswordHash, Role, Name, Email FROM student_staff WHERE UserID = ? OR Email = ? LIMIT 1`;
        const [results] = await connection.execute(sql, [usernameOrEmail, usernameOrEmail]);

        if (results.length === 0) {
            return res.status(401).send('Invalid username/email or password.');
        }

        const user = results[0];
        if (!user.PasswordHash) {
            return res.status(500).send('Internal server error: incomplete user data.');
        }

        const isMatch = await bcrypt.compare(password, user.PasswordHash);
        if (!isMatch) {
            return res.status(401).send('Invalid username/email or password.');
        }

        const updateLoginTime = `UPDATE student_staff SET LastLogin = NOW() WHERE UserID = ?`;
        await connection.execute(updateLoginTime, [user.UserID]);

        res.json({
            message: 'Login successful!',
            userId: user.UserID,
            role: user.Role,
            name: user.Name,
            email: user.Email
        });
    } catch (error) {
        console.error('Login error:', error.message);
        res.status(500).send('Internal server error during login.');
    } finally {
        if (connection) await connection.end();
    }
});

// Register endpoint
app.post('/register', async (req, res) => {
    const { userId, name, email, phoneNumber, password } = req.body;

    if (!userId || !name || !email || !password) {
        return res.status(400).send('UserID, name, email, and password are required.');
    }

    let role = 'user';
    if (email.endsWith('@cput.ac.za')) {
        role = 'admin';
    } else if (!email.endsWith('@mycput.ac.za')) {
        return res.status(400).send('Invalid email domain. Only @cput.ac.za or @mycput.ac.za are allowed.');
    }

    let connection;
    try {
        const passwordHash = await bcrypt.hash(password, 10);
        connection = await getDbConnection();
        const sql = `INSERT INTO student_staff (UserID, Name, Email, PhoneNumber, PasswordHash, Role) VALUES (?, ?, ?, ?, ?, ?)`;
        await connection.execute(sql, [userId, name, email, phoneNumber || null, passwordHash, role]);
        res.status(201).send('User registered successfully!');
    } catch (error) {
        console.error('DB error during registration:', error.message);
        if (error.code === 'ER_DUP_ENTRY') {
            if (error.sqlMessage.includes('UserID')) return res.status(409).send('User ID already exists.');
            if (error.sqlMessage.includes('Email')) return res.status(409).send('Email already registered.');
        }
        res.status(500).send('Error registering user.');
    } finally {
        if (connection) await connection.end();
    }
});

// Report Lost Item
app.post('/lost', upload.single('itemImage'), async (req, res) => {
    const { title, description, date_lost_found, reported_by_user_id, location_id, category_id } = req.body;
    const imageUrl = req.file ? `/uploads/${req.file.filename}` : null;

    if (!title || !description || !date_lost_found || !reported_by_user_id || !location_id || !category_id) {
        return res.status(400).send('Missing required fields.');
    }
    let connection;
    try {
        connection = await getDbConnection();
        const sql = `INSERT INTO items (Title, Description, ItemType, DateLostFound, DateReported, ReportedByUserID, LocationID, CategoryID, Status, ImageURL) VALUES (?, ?, 'Lost', ?, NOW(), ?, ?, ?, 'Active', ?)`;
        await connection.execute(sql, [title, description, date_lost_found, reported_by_user_id, location_id, category_id, imageUrl]);
        res.status(201).send('Lost item reported successfully!');
    } catch (error) {
        console.error('DB error adding lost item:', error.message);
        res.status(500).send('Error adding lost item.');
    } finally {
        if (connection) await connection.end();
    }
});

// Report Found Item
app.post('/found', upload.single('itemImage'), async (req, res) => {
    const { title, description, date_lost_found, reported_by_user_id, location_id, category_id } = req.body;
    const imageUrl = req.file ? `/uploads/${req.file.filename}` : null;

    if (!title || !description || !date_lost_found || !reported_by_user_id || !location_id || !category_id) {
        return res.status(400).send('Missing required fields.');
    }
    let connection;
    try {
        connection = await getDbConnection();
        const sql = `INSERT INTO items (Title, Description, ItemType, DateLostFound, DateReported, ReportedByUserID, LocationID, CategoryID, Status, ImageURL) VALUES (?, ?, 'Found', ?, NOW(), ?, ?, ?, 'Active', ?)`;
        await connection.execute(sql, [title, description, date_lost_found, reported_by_user_id, location_id, category_id, imageUrl]);
        res.status(201).send('Found item reported successfully!');
    } catch (error) {
        console.error('DB error adding found item:', error.message);
        res.status(500).send('Error adding found item.');
    } finally {
        if (connection) await connection.end();
    }
});

// Get all items with filters
app.get('/items', async (req, res) => {
    let connection;
    try {
        connection = await getDbConnection();
        let sql = `
            SELECT
                i.ItemID,
                i.Title,
                i.Description,
                i.ItemType,
                i.DateLostFound,
                i.ImageURL,
                l.Name AS LocationName,
                c.Name AS CategoryName,
                i.Status,
                i.ReportedByUserID
            FROM items i
            JOIN locations l ON i.LocationID = l.LocationID
            JOIN categories c ON i.CategoryID = c.CategoryID
            WHERE 1=1
        `;

        const params = [];
        const { type, category, status, location } = req.query;

        if (type) {
            sql += ` AND i.ItemType = ?`;
            params.push(type);
        }
        if (category) {
            sql += ` AND c.Name = ?`;
            params.push(category);
        }
        if (status) {
            sql += ` AND i.Status = ?`;
            params.push(status);
        }
        if (location) {
            sql += ` AND l.Name = ?`;
            params.push(location);
        }

        sql += ` ORDER BY i.DateReported DESC`;

        const [results] = await connection.execute(sql, params);
        res.json(results);
    } catch (error) {
        console.error('DB error fetching reported items:', error.message);
        res.status(500).send('Error fetching reported items.');
    } finally {
        if (connection) await connection.end();
    }
});

// Get categories for filters
app.get('/categories', async (req, res) => {
    let connection;
    try {
        connection = await getDbConnection();
        const sql = 'SELECT CategoryID, Name FROM categories ORDER BY Name';
        const [results] = await connection.execute(sql);
        res.json(results);
    } catch (error) {
        console.error('DB error fetching categories:', error.message);
        res.status(500).send('Error fetching categories.');
    } finally {
        if (connection) await connection.end();
    }
});

// Get locations for filters
app.get('/locations', async (req, res) => {
    let connection;
    try {
        connection = await getDbConnection();
        const sql = 'SELECT LocationID, Name FROM locations ORDER BY Name';
        const [results] = await connection.execute(sql);
        res.json(results);
    } catch (error) {
        console.error('DB error fetching locations:', error.message);
        res.status(500).send('Error fetching locations.');
    } finally {
        if (connection) await connection.end();
    }
});

// Get lost items with filters
app.get('/lost', async (req, res) => {
    const { category, location, status, limit = 20 } = req.query;
    let sql = `
        SELECT i.ItemID, i.Title, i.Description, i.ItemType, i.DateLostFound, i.ImageURL, l.Name AS LocationName, c.Name AS CategoryName, i.Status
        FROM items i
        JOIN locations l ON i.LocationID = l.LocationID
        JOIN categories c ON i.CategoryID = c.CategoryID
        WHERE i.ItemType = 'Lost' AND i.Status = 'Active'`;

    const params = [];
    if (category) {
        sql += ` AND c.Name = ?`;
        params.push(category);
    }
    if (location) {
        sql += ` AND l.Name = ?`;
        params.push(location);
    }
    sql += ` ORDER BY i.DateReported DESC LIMIT ?`;
    params.push(parseInt(limit));

    let connection;
    try {
        connection = await getDbConnection();
        const [results] = await connection.execute(sql, params);
        res.json(results);
    } catch (error) {
        console.error('DB error fetching lost items:', error.message);
        res.status(500).send('Error fetching lost items.');
    } finally {
        if (connection) await connection.end();
    }
});

// Get found items with filters
app.get('/found', async (req, res) => {
    const { category, location, status, limit = 20 } = req.query;
    let sql = `
        SELECT i.ItemID, i.Title, i.Description, i.ItemType, i.DateLostFound, i.ImageURL, l.Name AS LocationName, c.Name AS CategoryName, i.Status
        FROM items i
        JOIN locations l ON i.LocationID = l.LocationID
        JOIN categories c ON i.CategoryID = c.CategoryID
        WHERE i.ItemType = 'Found' AND i.Status = 'Active'`;

    const params = [];
    if (category) {
        sql += ` AND c.Name = ?`;
        params.push(category);
    }
    if (location) {
        sql += ` AND l.Name = ?`;
        params.push(location);
    }
    sql += ` ORDER BY i.DateReported DESC LIMIT ?`;
    params.push(parseInt(limit));

    let connection;
    try {
        connection = await getDbConnection();
        const [results] = await connection.execute(sql, params);
        res.json(results);
    } catch (error) {
        console.error('DB error fetching found items:', error.message);
        res.status(500).send('Error fetching found items.');
    } finally {
        if (connection) await connection.end();
    }
});

// Get all items reported by a specific user with filters
app.get('/my-items/:userId', async (req, res) => {
    const userId = req.params.userId;
    const { type, category, status, location } = req.query;
    if (!userId) {
        return res.status(400).send('User ID is required.');
    }
    let connection;
    try {
        connection = await getDbConnection();
        let sql = `
            SELECT i.ItemID, i.Title, i.Description, i.ItemType, i.DateLostFound, i.ImageURL, l.Name AS LocationName, c.Name AS CategoryName, i.Status
            FROM items i
            JOIN locations l ON i.LocationID = l.LocationID
            JOIN categories c ON i.CategoryID = c.CategoryID
            WHERE i.ReportedByUserID = ?`;
        const params = [userId];
        if (type) {
            sql += ` AND i.ItemType = ?`;
            params.push(type);
        }
        if (category) {
            sql += ` AND c.Name = ?`;
            params.push(category);
        }
        if (status) {
            sql += ` AND i.Status = ?`;
            params.push(status);
        }
        if (location) {
            sql += ` AND l.Name = ?`;
            params.push(location);
        }
        sql += ` ORDER BY i.DateReported DESC`;
        const [results] = await connection.execute(sql, params);
        res.json(results);
    } catch (error) {
        console.error('DB error fetching user-specific items:', error.message);
        res.status(500).send('Error fetching user-specific items.');
    } finally {
        if (connection) await connection.end();
    }
});

// Update user profile endpoint
app.put('/users/:userId/profile', async (req, res) => {
    const { userId } = req.params;
    const { name, phone } = req.body;

    if (!name || !phone) {
        return res.status(400).send('Name and phone number are required.');
    }

    let connection;
    try {
        connection = await getDbConnection();
        const sql = `UPDATE student_staff SET Name = ?, PhoneNumber = ? WHERE UserID = ?`;
        const [result] = await connection.execute(sql, [name, phone, userId]);

        if (result.affectedRows === 0) {
            return res.status(404).send('User not found.');
        }

        res.status(200).send('Profile updated successfully!');
    } catch (error) {
        console.error('DB error updating user profile:', error.message);
        res.status(500).send('Error updating user profile.');
    } finally {
        if (connection) await connection.end();
    }
});

// Update item status (for admin)
app.put('/items/:itemId/status', async (req, res) => {
    const { itemId } = req.params;
    const { status } = req.body;
    let connection;
    try {
        connection = await getDbConnection();
        const sql = `UPDATE items SET Status = ? WHERE ItemID = ?`;
        const [result] = await connection.execute(sql, [status, itemId]);

        if (result.affectedRows === 0) {
            return res.status(404).send('Item not found.');
        }

        res.status(200).send('Item status updated successfully!');
    } catch (error) {
        console.error('DB error updating item status:', error.message);
        res.status(500).send('Error updating item status.');
    } finally {
        if (connection) await connection.end();
    }
});

// Get all data for admin dashboard
app.get('/admin/data', async (req, res) => {
    let connection;
    try {
        connection = await getDbConnection();
        const [items] = await connection.execute('SELECT * FROM items');
        const [users] = await connection.execute('SELECT * FROM student_staff');
        res.json({ items, users });
    } catch (error) {
        console.error('DB error fetching admin data:', error.message);
        res.status(500).send('Error fetching admin data.');
    } finally {
        if (connection) await connection.end();
    }
});

// Admin endpoint to delete an item post
app.delete('/admin/items/:itemId', async (req, res) => {
    const { itemId } = req.params;
    let connection;
    try {
        connection = await getDbConnection();
        const sql = `DELETE FROM items WHERE ItemID = ?`;
        const [result] = await connection.execute(sql, [itemId]);

        if (result.affectedRows === 0) {
            return res.status(404).send('Item not found.');
        }

        res.status(200).send('Item deleted successfully!');
    } catch (error) {
        console.error('DB error deleting item:', error.message);
        res.status(500).send('Error deleting item.');
    } finally {
        if (connection) await connection.end();
    }
});

// Admin endpoint to delete a user
app.delete('/admin/users/:userId', async (req, res) => {
    const { userId } = req.params;
    let connection;
    try {
        connection = await getDbConnection();
        await connection.beginTransaction();

        // 1. Delete all items reported by the user to satisfy foreign key constraints
        const deleteItemsSql = `DELETE FROM items WHERE ReportedByUserID = ?`;
        await connection.execute(deleteItemsSql, [userId]);

        // 2. Delete the user
        const deleteUserSql = `DELETE FROM student_staff WHERE UserID = ?`;
        const [result] = await connection.execute(deleteUserSql, [userId]);

        if (result.affectedRows === 0) {
            await connection.rollback();
            return res.status(404).send('User not found or has admin privileges.');
        }

        await connection.commit();
        res.status(200).send('User and their posts deleted successfully!');
    } catch (error) {
        await connection.rollback();
        console.error('DB error deleting user:', error.message);
        res.status(500).send('Error deleting user.');
    } finally {
        if (connection) await connection.end();
    }
});
// Get stats - total lost items
app.get('/stats/lost', async (req, res) => {
    let connection;
    try {
        connection = await getDbConnection();
        const sql = `SELECT COUNT(*) AS count FROM items WHERE ItemType = 'Lost' AND Status = 'Active'`;
        const [results] = await connection.execute(sql);
        res.json({ count: results[0].count });
    } catch (error) {
        console.error('DB error fetching lost stats:', error.message);
        res.status(500).send('Error fetching lost stats.');
    } finally {
        if (connection) await connection.end();
    }
});

// Get stats - total found items
app.get('/stats/found', async (req, res) => {
    let connection;
    try {
        connection = await getDbConnection();
        const sql = `SELECT COUNT(*) AS count FROM items WHERE ItemType = 'Found' AND Status = 'Active'`;
        const [results] = await connection.execute(sql);
        res.json({ count: results[0].count });
    } catch (error) {
        console.error('DB error fetching found stats:', error.message);
        res.status(500).send('Error fetching found stats.');
    } finally {
        if (connection) await connection.end();
    }
});

// Get stats - user's reported items count
app.get('/stats/myreported/:userId', async (req, res) => {
    const userId = req.params.userId;
    let connection;
    try {
        connection = await getDbConnection();
        const sql = `SELECT COUNT(*) AS count FROM items WHERE ReportedByUserID = ? AND Status = 'Active'`;
        const [results] = await connection.execute(sql, [userId]);
        res.json({ count: results[0].count });
    } catch (error) {
        console.error('DB error fetching myreported stats:', error.message);
        res.status(500).send('Error fetching my reported stats.');
    } finally {
        if (connection) await connection.end();
    }
});

// Start server
app.listen(PORT, async () => {
    console.log(`🚀 Server running on http://localhost:${PORT}`);
    try {
        const connection = await getDbConnection();
        console.log('📦 Database connected successfully!');
        await connection.end();
    } catch (error) {
        console.error('❌ Failed to connect to the database:', error.message);
        process.exit(1);
    }
});